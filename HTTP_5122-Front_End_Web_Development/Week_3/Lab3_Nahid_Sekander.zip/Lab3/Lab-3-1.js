//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS
const fruits = ['apple', 'pear', 'orange', 'banana', 'peach']

//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX
//for(var i = 0; i < fruits.length; i++)
{
    alert("Frutis : " + fruits[0])
}

